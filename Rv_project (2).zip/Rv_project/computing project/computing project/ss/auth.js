import { auth, db } from "./firebase-config.js";
import { signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function loginUser(email, password) {
  const result = await signInWithEmailAndPassword(auth, email, password);
  const uid = result.user.uid;

  const userRef = doc(db, "users", uid);
  const userSnap = await getDoc(userRef);

  if (!userSnap.exists()) {
    throw new Error("User profile not found in Firestore.");
  }

  return {
    uid,
    ...userSnap.data()
  };
}

export function redirectByRole(userData) {
  if (userData.role === "admin") {
    window.location.href = "admindash.html";
  } else if (userData.role === "owner") {
    window.location.href = "ownerdashboard.html";
  } else if (userData.role === "delivery") {
    window.location.href = "deliverydash.html";
  } else if (userData.role === "staff") {
    window.location.href = "staffdash.html";
  } else {
    alert("Unknown role");
  }
}

export function watchAuth(callback) {
  onAuthStateChanged(auth, callback);
}

export async function logoutUser() {
  await signOut(auth);
}