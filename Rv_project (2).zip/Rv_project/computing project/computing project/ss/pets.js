import { db, auth } from "./firebase-config.js";
import {
  collection,
  addDoc,
  getDocs,
  query,
  where,
  doc,
  updateDoc,
  deleteDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function addPet(petData) {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  await addDoc(collection(db, "pets"), {
    ownerId: currentUser.uid,
    name: petData.name,
    type: petData.type,
    breed: petData.breed,
    age: petData.age,
    healthHistory: petData.healthHistory || "",
    vaccinationRecords: petData.vaccinationRecords || "",
    feedingPreferences: petData.feedingPreferences || "",
    behaviorNotes: petData.behaviorNotes || "",
    createdAt: serverTimestamp()
  });
}

export async function getMyPets() {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  const q = query(collection(db, "pets"), where("ownerId", "==", currentUser.uid));
  const snapshot = await getDocs(q);

  return snapshot.docs.map(docSnap => ({
    id: docSnap.id,
    ...docSnap.data()
  }));
}

export async function updatePet(petId, updatedData) {
  const petRef = doc(db, "pets", petId);
  await updateDoc(petRef, updatedData);
}

export async function deletePet(petId) {
  const petRef = doc(db, "pets", petId);
  await deleteDoc(petRef);
}