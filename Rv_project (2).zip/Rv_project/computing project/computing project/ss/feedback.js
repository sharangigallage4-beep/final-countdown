import { db, auth } from "./firebase-config.js";
import {
  collection,
  addDoc,
  getDocs,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function submitFeedback(rating, comment) {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  await addDoc(collection(db, "feedback"), {
    ownerId: currentUser.uid,
    rating,
    comment,
    createdAt: serverTimestamp()
  });
}

export async function getAllFeedback() {
  const snapshot = await getDocs(collection(db, "feedback"));
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}