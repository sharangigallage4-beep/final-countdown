import { db, auth } from "./firebase-config.js";
import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function addDeliveryUpdate(orderId, status, locationText) {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  await addDoc(collection(db, "delivery_tracking"), {
    orderId,
    deliveryPersonId: currentUser.uid,
    status,
    locationText,
    updatedAt: serverTimestamp()
  });
}

export async function getDeliveryUpdates(orderId) {
  const q = query(collection(db, "delivery_tracking"), where("orderId", "==", orderId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}