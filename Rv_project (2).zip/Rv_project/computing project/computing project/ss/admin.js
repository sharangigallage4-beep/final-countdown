import { db } from "./firebase-config.js";
import {
  collection,
  getDocs
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

async function countCollection(name) {
  const snapshot = await getDocs(collection(db, name));
  return snapshot.size;
}

export async function getDashboardCounts() {
  const [users, pets, bookings, orders, feedback] = await Promise.all([
    countCollection("users"),
    countCollection("pets"),
    countCollection("bookings"),
    countCollection("orders"),
    countCollection("feedback")
  ]);

  return { users, pets, bookings, orders, feedback };
}