import { db, auth } from "./firebase-config.js";
import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function getProducts() {
  const snapshot = await getDocs(collection(db, "products"));
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function placeOrder(items, totalAmount) {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  await addDoc(collection(db, "orders"), {
    ownerId: currentUser.uid,
    items,
    totalAmount,
    paymentStatus: "pending",
    deliveryStatus: "processing",
    createdAt: serverTimestamp()
  });
}