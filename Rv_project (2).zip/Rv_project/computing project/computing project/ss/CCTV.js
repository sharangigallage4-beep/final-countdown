import { db, auth } from "./firebase-config.js";
import {
  collection,
  getDocs,
  query,
  where
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function getMyCctvAccess() {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  const q = query(collection(db, "cctv_access"), where("ownerId", "==", currentUser.uid));
  const snapshot = await getDocs(q);

  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}