import { db, auth } from "./firebase-config.js";
import {
  collection,
  addDoc,
  getDocs,
  query,
  where,
  doc,
  updateDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function createBooking(data) {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("User not logged in");

  await addDoc(collection(db, "bookings"), {
    ownerId: currentUser.uid,
    petId: data.petId,
    serviceType: data.serviceType,
    date: data.date,
    timeSlot: data.timeSlot,
    notes: data.notes || "",
    status: "pending",
    createdAt: serverTimestamp()
  });
}

export async function getMyBookings() {
  const currentUser = auth.currentUser;
  const q = query(collection(db, "bookings"), where("ownerId", "==", currentUser.uid));
  const snapshot = await getDocs(q);

  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function updateBookingStatus(bookingId, status) {
  await updateDoc(doc(db, "bookings", bookingId), { status });
}